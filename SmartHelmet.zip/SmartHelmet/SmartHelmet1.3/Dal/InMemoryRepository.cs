using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Entity;
using MongoDB.Driver;

namespace Dal
{
    /// <summary>
    /// Repositorio "en memoria" que además persiste automáticamente
    /// las detecciones (y el semáforo) en archivos .txt.
    /// </summary>
    public class InMemoryRepository
    {
        private readonly List<Deteccion> _detecciones = new List<Deteccion>();
        private readonly List<Vehiculo> _vehiculos = new List<Vehiculo>();
        private readonly List<Semaforo> _semaforos = new List<Semaforo>();

        private int _detId = 1;

        private readonly string _basePath;
        private readonly string _semaforosFile;
        private readonly string _vehiculosFile;
        private readonly string _mongoConnectionString;
        private readonly IMongoCollection<Deteccion> _deteccionesCollection;
        private const string DefaultMongoConnectionString =
            "mongodb+srv://glucialopez_db_user:ncKY3xgjT5h9RdUN@cluster0.bxcz1hg.mongodb.net/?appName=Cluster0";

        public InMemoryRepository(
            string basePath = "Data",
            string mongoConnectionString = null,
            string databaseName = "SmartHelmetDb",
            string deteccionesCollectionName = "detecciones")
        {
            _basePath = basePath;
            _semaforosFile = Path.Combine(_basePath, "semaforos.txt");
            _vehiculosFile = Path.Combine(_basePath, "vehiculos.txt");
            _mongoConnectionString = mongoConnectionString
                                      ?? Environment.GetEnvironmentVariable("SMARTHELMET_MONGO_CONN")
                                      ?? DefaultMongoConnectionString;

            var mongoClient = new MongoClient(_mongoConnectionString);
            var mongoDatabase = mongoClient.GetDatabase(databaseName);
            _deteccionesCollection = mongoDatabase.GetCollection<Deteccion>(deteccionesCollectionName);

            Directory.CreateDirectory(_basePath);

            CargarSemaforos();
            CargarVehiculos();
            CargarDetecciones();
        }

        #region Carga inicial desde archivo

        private void CargarDetecciones()
        {
            _detecciones.Clear();

            var todasLasDetecciones = _deteccionesCollection
                .Find(FilterDefinition<Deteccion>.Empty)
                .SortBy(d => d.Id)
                .ToList();

            foreach (var d in todasLasDetecciones)
            {
                _detecciones.Add(d);
            }

            _detId = _detecciones.Any() ? _detecciones.Max(x => x.Id) + 1 : 1;
        }

        private void CargarSemaforos()
        {
            _semaforos.Clear();

            if (!File.Exists(_semaforosFile))
            {
                // Semáforo por defecto
                var sem = new Semaforo
                {
                    Id = 1,
                    EstadoActual = EstadoSemaforo.Rojo,
                    UltimoCambio = DateTime.Now,
                    Ubicacion = "Principal"
                };
                _semaforos.Add(sem);
                GuardarSemaforos();
                return;
            }

            foreach (var line in File.ReadAllLines(_semaforosFile))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                var parts = line.Split(';');
                if (parts.Length < 4) continue;

                _semaforos.Add(new Semaforo
                {
                    Id = int.Parse(parts[0]),
                    EstadoActual = (EstadoSemaforo)Enum.Parse(typeof(EstadoSemaforo), parts[1]),
                    UltimoCambio = DateTime.ParseExact(parts[2], "o", CultureInfo.InvariantCulture),
                    Ubicacion = parts[3]
                });
            }

            if (_semaforos.Count == 0)
            {
                var sem = new Semaforo
                {
                    Id = 1,
                    EstadoActual = EstadoSemaforo.Rojo,
                    UltimoCambio = DateTime.Now,
                    Ubicacion = "Principal"
                };
                _semaforos.Add(sem);
                GuardarSemaforos();
            }
        }

        private void CargarVehiculos()
        {
            _vehiculos.Clear();

            if (!File.Exists(_vehiculosFile))
            {
                return;
            }

            foreach (var line in File.ReadAllLines(_vehiculosFile))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                var parts = line.Split(';');
                if (parts.Length < 3) continue;

                _vehiculos.Add(new Vehiculo
                {
                    Id = int.Parse(parts[0]),
                    Placa = parts[1],
                    Tipo = parts[2]
                });
            }
        }

        #endregion

        #region Persistencia a archivo

        private void InsertDeteccionInMongo(Deteccion d)
        {
            _deteccionesCollection.InsertOne(d);
        }

        private void GuardarSemaforos()
        {
            using (var writer = new StreamWriter(_semaforosFile, append: false))
            {
                foreach (var s in _semaforos)
                {
                    string line = string.Join(";",
                        s.Id.ToString(),
                        s.EstadoActual.ToString(),
                        s.UltimoCambio.ToString("o", CultureInfo.InvariantCulture),
                        s.Ubicacion ?? string.Empty
                    );
                    writer.WriteLine(line);
                }
            }
        }

        private void GuardarVehiculos()
        {
            using (var writer = new StreamWriter(_vehiculosFile, append: false))
            {
                foreach (var v in _vehiculos)
                {
                    string line = string.Join(";",
                        v.Id.ToString(),
                        v.Placa ?? string.Empty,
                        v.Tipo ?? string.Empty
                    );
                    writer.WriteLine(line);
                }
            }
        }

        #endregion

        #region API pública usada por la BLL / UI

        public Deteccion AddDeteccion(Deteccion d)
        {
            if (d == null) throw new ArgumentNullException(nameof(d));

            d.Id = _detId++;
            if (d.Hora == default)
                d.Hora = DateTime.Now;

            _detecciones.Add(d);
            InsertDeteccionInMongo(d);

            return d;
        }

        public IEnumerable<Deteccion> GetUltimas(int count = 20)
        {
            return _detecciones
                .OrderByDescending(x => x.Hora)
                .Take(count)
                .ToList();
        }

        public Semaforo GetSemaforo()
        {
            return _semaforos.First();
        }

        public void UpdateSemaforo(Semaforo s)
        {
            if (s == null) throw new ArgumentNullException(nameof(s));

            var ex = _semaforos.FirstOrDefault(x => x.Id == s.Id);
            if (ex == null)
            {
                _semaforos.Add(s);
            }
            else
            {
                ex.EstadoActual = s.EstadoActual;
                ex.UltimoCambio = s.UltimoCambio;
                ex.Ubicacion = s.Ubicacion;
            }

            GuardarSemaforos();
        }

        // Métodos básicos para vehículos (por si luego los necesitas)

        public Vehiculo AddVehiculo(Vehiculo v)
        {
            if (v == null) throw new ArgumentNullException(nameof(v));

            int nextId = _vehiculos.Any() ? _vehiculos.Max(x => x.Id) + 1 : 1;
            v.Id = nextId;
            _vehiculos.Add(v);
            GuardarVehiculos();
            return v;
        }

        public IEnumerable<Vehiculo> GetVehiculos()
        {
            return _vehiculos.ToList();
        }

        #endregion
    }
}
