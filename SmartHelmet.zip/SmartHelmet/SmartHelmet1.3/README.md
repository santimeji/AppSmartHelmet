SmartHelmet - versión adaptada a partir de tu 'Parcial Corte 1'.

Proyectos incluidos:
- Entity: entidades (Vehiculo, Deteccion, Semaforo)
- Dal: repositorio en memoria (InMemoryRepository)
- BILL: lógica de negocio (DeteccionService)
- AppTienda: WinForms app para simular detecciones y ver semáforo

Cómo abrir:
- Abre `SmartHelmet_From_Parcial.sln` en Visual Studio 2022/2019.
- Establece `AppTienda` como proyecto de inicio y ejecuta.
- Presiona 'Simular Detección' para generar detecciones y ver el estado del semáforo.

Nota:
- La detección es simulada. Para integrar cámara o IA real, reemplace `DeteccionService.DetectarSimulado`.
