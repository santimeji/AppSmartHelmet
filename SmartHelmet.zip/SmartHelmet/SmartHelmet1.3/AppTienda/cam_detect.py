import cv2
from ultralytics import YOLO

# Cargar tu modelo entrenado
model = YOLO("best.pt")

# Activar backend rápido para CPU
model.to("cpu")
model.fuse()  # optimiza las capas, mejora FPS

cap = cv2.VideoCapture(0)

# Configuración para máxima fluidez
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640) 
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
cap.set(cv2.CAP_PROP_FPS, 30)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Reducción agresiva de tamaño (mucho más FPS)
    frame_small = cv2.resize(frame, (320, 240))

    # Detección optimizada
    results = model(frame_small, stream=True, verbose=False)

    for r in results:
        annotated = r.plot()

        cv2.imshow("Detección en vivo (Optimizada CPU)", annotated)

    # Salida con Q
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
