using AForge.Video;
using AForge.Video.DirectShow;
using BILL;
using Dal;
using Entity;
using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;
using System.Drawing.Drawing2D;


namespace AppSmartHelmet
{
    public partial class MainForm : Form
    {
        private System.Windows.Forms.Timer timerDeteccion;
        private HttpClient http = new HttpClient();
        private System.Diagnostics.Process procesoPython;
        private Thread lectorThread;
        private bool leyendoStream = false;
        private readonly DeteccionService _detService;
        private readonly InMemoryRepository _repo;

        // --- Variables para la cámara ---
        private FilterInfoCollection _dispositivos;
        private VideoCaptureDevice _fuenteVideo;

        public MainForm(DeteccionService detService, InMemoryRepository repo)
        {
            _detService = detService;
            _repo = repo;
            InitializeComponent();
            CargarDispositivos();
            timerDeteccion = new System.Windows.Forms.Timer();
            timerDeteccion.Interval = 300; // consulta cada 0.3 segundos
            timerDeteccion.Tick += TimerDeteccion_Tick;

        }
       

        public void Roundify(Control c, int radius = 12)
        {
            var path = new GraphicsPath();
            int d = radius * 2;
            var r = c.ClientRectangle;

            path.AddArc(r.X, r.Y, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();

            c.Region = new Region(path);
        }
     

    // --- Inicializa la lista de cámaras disponibles ---
    private void CargarDispositivos()
        {
            try
            {
                _dispositivos = new FilterInfoCollection(FilterCategory.VideoInputDevice);

                cmbCamaras.Items.Clear();

                foreach (FilterInfo dispositivo in _dispositivos)
                {
                    cmbCamaras.Items.Add(dispositivo.Name);
                }

                if (_dispositivos.Count > 0)
                    cmbCamaras.SelectedIndex = 0;
                else
                    MessageBox.Show("No se detectaron cámaras disponibles.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar cámaras: {ex.Message}");
            }
        }
        private async void IniciarStream(string url)
        {
            try
            {
                HttpClient client = new HttpClient();
                var response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
                var stream = await response.Content.ReadAsStreamAsync();

                byte[] buffer = new byte[4096];
                MemoryStream imageBuffer = new MemoryStream();

                while (true)
                {
                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                    if (bytesRead == 0) continue;

                    // Buscar comienzo de JPG
                    for (int i = 0; i < bytesRead - 1; i++)
                    {
                        if (buffer[i] == 0xFF && buffer[i + 1] == 0xD8)
                        {
                            imageBuffer.SetLength(0); // limpiar buffer
                        }
                    }

                    imageBuffer.Write(buffer, 0, bytesRead);

                    // Buscar fin de JPG
                    if (buffer[bytesRead - 2] == 0xFF && buffer[bytesRead - 1] == 0xD9)
                    {
                        try
                        {
                            using (var ms = new MemoryStream(imageBuffer.ToArray()))
                            {
                                Bitmap bmp = new Bitmap(ms);

                                pbCamara.Invoke(new Action(() =>
                                {
                                    pbCamara.Image = bmp;
                                }));
                            }
                        }
                        catch { }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en el stream: " + ex.Message);
            }
        }



        // --- Botón para iniciar la cámara ---
        MjpegStreamReader streamReader;

        private MjpegStreamReader _reader;

        private async void btnIniciarCamara_Click(object sender, EventArgs e)
        {
            _reader = new MjpegStreamReader("http://127.0.0.1:5000/video");

            _reader.FrameReceived += (bmp) =>
            {
                if (pbCamara.InvokeRequired)
                    pbCamara.Invoke(new Action(() => pbCamara.Image = bmp));
                else
                    pbCamara.Image = bmp;
            };

            await _reader.StartAsync();

            // 🔥 ACTIVAR LECTURA AUTOMÁTICA DE DETECCIÓN
            timerDeteccion.Start();
        }

        // --- Mostrar la imagen en el PictureBox ---
        private void Capturando(object sender, NewFrameEventArgs eventArgs)
        {
            try
            {
                if (pbCamara.InvokeRequired)
                {
                    pbCamara.Invoke(new MethodInvoker(() =>
                    {
                        pbCamara.Image = (Bitmap)eventArgs.Frame.Clone();
                    }));
                }
                else
                {
                    pbCamara.Image = (Bitmap)eventArgs.Frame.Clone();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al capturar frame: {ex.Message}");
            }
        }


        private async void btnDetenerCamara_Click(object sender, EventArgs e)
        {
            timerDeteccion.Stop();
            _reader?.Stop();

            // Opcional: registrar una última detección
            try
            {
                await RegistrarDeteccionDesdeServicioAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar la detección final: " + ex.Message);
            }
        }

        private void HacerCircular(Control ctrl)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddEllipse(0, 0, ctrl.Width, ctrl.Height);
            ctrl.Region = new Region(path);
        }

       

        //--- Simulación de detección(botón Detect) ---
        private void btnDetect_Click(object sender, EventArgs e)
        {
            try
            {
                if (pbCamara.Image == null)
                {
                    MessageBox.Show("Primero debes iniciar la cámara para capturar una imagen.");
                    return;
                }

                // --- Captura un frame actual ---
                Bitmap frameActual = new Bitmap(pbCamara.Image);

                // --- Detección simulada (aleatoria) ---
                Random rnd = new Random();
                bool tieneCasco = rnd.Next(2) == 0; // 50% probabilidad
                double confianza = Math.Round(rnd.NextDouble() * (0.9 - 0.6) + 0.6, 2); // entre 0.6 y 0.9

                // --- Mostrar resultado en mensaje ---
                string mensaje = tieneCasco
                    ? $"🟢 Persona detectada CON CASCO\nConfianza: {confianza * 100}%"
                    : $"🔴 Persona detectada SIN CASCO\nConfianza: {confianza * 100}%";

                MessageBox.Show(mensaje, "Resultado de detección");

                // --- Actualizar UI del semáforo ---
                pbSemaforo.BackColor = tieneCasco ? Color.White : Color.Red;
                pbSemafor.BackColor = tieneCasco ? Color.Green : Color.White;
                lblSemaforo.Text = tieneCasco ? "Semáforo: VERDE" : "Semáforo: ROJO";

                // --- Mostrar el resultado visualmente sobre la imagen ---
                using (Graphics g = Graphics.FromImage(frameActual))
                {
                    Color color = tieneCasco ? Color.Lime : Color.Red;
                    Pen pen = new Pen(color, 5);
                    g.DrawRectangle(pen, 50, 50, frameActual.Width - 100, frameActual.Height - 100);
                    g.DrawString(
                        tieneCasco ? "CON CASCO" : "SIN CASCO",
                        new Font("Arial", 16, FontStyle.Bold),
                        new SolidBrush(color),
                        new PointF(20, 20)
                    );
                }

                // Actualiza el PictureBox con la imagen procesada
                pbCamara.Image = frameActual;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al simular la detección: {ex.Message}");
            }
        }
        private async Task RegistrarDeteccionDesdeServicioAsync()
        {
            string json = await http.GetStringAsync("http://127.0.0.1:5000/status");

            dynamic data = JsonConvert.DeserializeObject(json);

            bool tieneCasco = data.helmet;
            double confianza = data.confidence;

            // actualizar semáforo igual que antes...

            var deteccion = new Deteccion
            {
                TieneCasco = tieneCasco,
                NivelConfianza = confianza,
                Hora = DateTime.Now,
                Imagen = null,//GuardarFrameActualYObtenerRuta(),
                VehiculoId = null
            };

            _repo.AddDeteccion(deteccion);
        }

        private async void TimerDeteccion_Tick(object sender, EventArgs e)
        {
            try
            {
                string json = await http.GetStringAsync("http://127.0.0.1:5000/status");

                dynamic data = JsonConvert.DeserializeObject(json);

                bool tieneCasco = data.helmet;
                double confianza = data.confidence;

                // --- Cambiar ambos semáforos ---
                if (tieneCasco)
                {
                    // CASCO DETECTADO → VERDE
                    pbSemaforo.BackColor = Color.White;
                    pbSemafor.BackColor = Color.Green;
                    lblSemaforo.Text = "Semáforo: VERDE";
                }
                else
                {
                    // SIN CASCO → ROJO
                    pbSemaforo.BackColor = Color.Red;
                    pbSemafor.BackColor = Color.White;
                    lblSemaforo.Text = "Semáforo: ROJO";
                }
            }
            catch
            {
                // Ignora errores cuando Python aún no responde
            }
        }


        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_fuenteVideo != null && _fuenteVideo.IsRunning)
                _fuenteVideo.SignalToStop();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            HacerCircular(pbSemaforo);
            HacerCircular(pbSemafor);
            HacerCircular(pictureBox2);
        }

        private void dgvUltimas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void proyectname_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblSemaforo_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void pbCamara_Click(object sender, EventArgs e)
        {

        }

        private void MainForm_Shown_1(object sender, EventArgs e)
        {
            Roundify(panel1, 15);
            Roundify(btnDetect, 8);
            Roundify(btnDetenerCamara, 8);
            Roundify(btnIniciarCamara, 8);
        }

        private void pbSemaforo_Click(object sender, EventArgs e)
        {

        }
    }
}