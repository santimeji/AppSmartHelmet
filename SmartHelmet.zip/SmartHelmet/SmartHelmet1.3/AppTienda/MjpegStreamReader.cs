﻿using System;
using System.Drawing;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

public class MjpegStreamReader
{
    private readonly string _url;
    private readonly HttpClient _client = new HttpClient();
    private CancellationTokenSource _cts;

    public event Action<Bitmap> FrameReceived;

    public MjpegStreamReader(string url)
    {
        _url = url;
    }

    public async Task StartAsync()
    {
        _cts = new CancellationTokenSource();

        var response = await _client.GetAsync(_url, HttpCompletionOption.ResponseHeadersRead);
        var stream = await response.Content.ReadAsStreamAsync();

        byte[] boundaryBytes = System.Text.Encoding.ASCII.GetBytes("--frame");
        byte[] buffer = new byte[4096];
        MemoryStream imageBuffer = new MemoryStream();

        while (!_cts.IsCancellationRequested)
        {
            int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
            if (bytesRead <= 0) continue;

            imageBuffer.Write(buffer, 0, bytesRead);

            // Buscar boundary
            int boundaryIndex = IndexOf(imageBuffer.ToArray(), boundaryBytes);
            if (boundaryIndex >= 0)
            {
                // Buscar el inicio real del JPEG
                byte[] jpegMagic = { 0xFF, 0xD8 }; // SOI
                byte[] data = imageBuffer.ToArray();

                int jpegStart = IndexOf(data, jpegMagic);
                int jpegEnd = LastIndexOfJpeg(data);

                if (jpegStart >= 0 && jpegEnd > jpegStart)
                {
                    int jpegLength = jpegEnd - jpegStart;

                    try
                    {
                        using (var ms = new MemoryStream(data, jpegStart, jpegLength))
                        {
                            Bitmap bmp = new Bitmap(ms);
                            FrameReceived?.Invoke(bmp);
                        }
                    }
                    catch { }

                    imageBuffer.Dispose();
                    imageBuffer = new MemoryStream();
                }
            }
        }
    }

    public void Stop()
    {
        _cts?.Cancel();
    }

    // Buscar bytes dentro de un array
    private int IndexOf(byte[] buffer, byte[] pattern)
    {
        for (int i = 0; i < buffer.Length - pattern.Length; i++)
        {
            bool match = true;
            for (int j = 0; j < pattern.Length; j++)
            {
                if (buffer[i + j] != pattern[j])
                {
                    match = false;
                    break;
                }
            }
            if (match) return i;
        }
        return -1;
    }

    private int LastIndexOfJpeg(byte[] buffer)
    {
        // JPEG termina con FF D9
        for (int i = buffer.Length - 2; i >= 0; i--)
        {
            if (buffer[i] == 0xFF && buffer[i + 1] == 0xD9)
                return i + 2;
        }
        return -1;
    }
}
