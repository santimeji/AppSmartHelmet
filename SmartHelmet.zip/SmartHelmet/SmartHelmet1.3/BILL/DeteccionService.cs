using System;
using Entity;
using Dal;

namespace BILL
{
    public class DeteccionService
    {
        private readonly InMemoryRepository _repo;
        private readonly Random _rnd = new Random();

        public DeteccionService(InMemoryRepository repo)
        {
            _repo = repo;
        }

        // Simula la detección (más tarde puede recibir una imagen)
        public Deteccion DetectarSimulado()
        {
            var confianza = Math.Round(_rnd.NextDouble() * 0.6 + 0.4, 2);
            var tieneCasco = _rnd.NextDouble() > 0.25; // 75% con casco
            var det = new Deteccion
            {
                Hora = DateTime.Now,
                NivelConfianza = confianza,
                TieneCasco = tieneCasco,
                Imagen = null
            };

            _repo.AddDeteccion(det);

            var sem = _repo.GetSemaforo();
            if (!tieneCasco) sem.EstadoActual = EstadoSemaforo.Rojo;
            else sem.EstadoActual = EstadoSemaforo.Verde;
            sem.UltimoCambio = DateTime.Now;
            _repo.UpdateSemaforo(sem);

            return det;
        }
    }
}
