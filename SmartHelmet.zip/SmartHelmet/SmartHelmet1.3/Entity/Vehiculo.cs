using System;

namespace Entity
{
    public class Vehiculo
    {
        public int Id { get; set; }
        public string Placa { get; set; }
        public string Tipo { get; set; } = "Moto";
    }
}
