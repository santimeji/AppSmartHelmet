using System;

namespace Entity
{
    public class Deteccion
    {
        public int Id { get; set; }
        public DateTime Hora { get; set; } = DateTime.Now;
        public bool TieneCasco { get; set; }
        public double NivelConfianza { get; set; }
        public string Imagen { get; set; }
        public int? VehiculoId { get; set; }
    }
}
