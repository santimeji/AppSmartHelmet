using AForge.Video;
using AForge.Video.DirectShow;
using BILL;
using Dal;
using Entity;
using Newtonsoft.Json;
using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Windows.Forms;

namespace AppSmartHelmet
{
    public partial class MainForm : Form
    {
        private readonly DeteccionService _detService;
        private readonly InMemoryRepository _repo;

        // --- Variables para la cámara ---
        private FilterInfoCollection _dispositivos;
        private VideoCaptureDevice _fuenteVideo;

        public MainForm(DeteccionService detService, InMemoryRepository repo)
        {
            _detService = detService;
            _repo = repo;
            InitializeComponent();
            CargarDispositivos();
        }

        // --- Inicializa la lista de cámaras disponibles ---
        private void CargarDispositivos()
        {
            try
            {
                _dispositivos = new FilterInfoCollection(FilterCategory.VideoInputDevice);

                cmbCamaras.Items.Clear();

                foreach (FilterInfo dispositivo in _dispositivos)
                {
                    cmbCamaras.Items.Add(dispositivo.Name);
                }

                if (_dispositivos.Count > 0)
                    cmbCamaras.SelectedIndex = 0;
                else
                    MessageBox.Show("No se detectaron cámaras disponibles.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar cámaras: {ex.Message}");
            }
        }


        // --- Botón para iniciar la cámara ---
        private void btnIniciarCamara_Click(object sender, EventArgs e)
        {
            try
            {
                if (_dispositivos == null || _dispositivos.Count == 0)
                {
                    MessageBox.Show("No hay cámaras disponibles.");
                    return;
                }

                // Mostrar listado para ver qué índice tiene tu cámara real
                string lista = string.Join("\n", _dispositivos.Cast<FilterInfo>().Select((d, i) => $"{i}: {d.Name}"));
                MessageBox.Show($"Cámaras detectadas:\n{lista}");

                // --- Cambia este número según el índice que tenga tu HP TrueVision ---
                int indiceHP = 4; // ← si HP TrueVision es la quinta en la lista, usa 4 (empieza en 0)

                if (indiceHP >= _dispositivos.Count)
                {
                    MessageBox.Show("El índice de cámara seleccionado no existe.");
                    return;
                }

                var dispositivo = _dispositivos[indiceHP];

                // Detener cualquier cámara previa
                if (_fuenteVideo != null && _fuenteVideo.IsRunning)
                {
                    _fuenteVideo.SignalToStop();
                    _fuenteVideo = null;
                }

                // Iniciar cámara forzada
                _fuenteVideo = new VideoCaptureDevice(dispositivo.MonikerString);
                _fuenteVideo.NewFrame += Capturando;
                _fuenteVideo.Start();

                MessageBox.Show($"✅ Cámara iniciada correctamente: {dispositivo.Name}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al iniciar cámara: {ex.Message}");
            }
        }

        // --- Mostrar la imagen en el PictureBox ---
        private void Capturando(object sender, NewFrameEventArgs eventArgs)
        {
            try
            {
                if (pbCamara.InvokeRequired)
                {
                    pbCamara.Invoke(new MethodInvoker(() =>
                    {
                        pbCamara.Image = (Bitmap)eventArgs.Frame.Clone();
                    }));
                }
                else
                {
                    pbCamara.Image = (Bitmap)eventArgs.Frame.Clone();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al capturar frame: {ex.Message}");
            }
        }


        // --- Detener la cámara ---
        private void btnDetenerCamara_Click(object sender, EventArgs e)
        {
            if (_fuenteVideo != null && _fuenteVideo.IsRunning)
            {
                _fuenteVideo.SignalToStop();
                _fuenteVideo = null;
            }
        }

         //--- Simulación de detección(botón Detect) ---
        private void btnDetect_Click(object sender, EventArgs e)
        {
            try
            {
                if (pbCamara.Image == null)
                {
                    MessageBox.Show("Primero debes iniciar la cámara para capturar una imagen.");
                    return;
                }

                // --- Captura un frame actual ---
                Bitmap frameActual = new Bitmap(pbCamara.Image);

                // --- Detección simulada (aleatoria) ---
                Random rnd = new Random();
                bool tieneCasco = rnd.Next(2) == 0; // 50% probabilidad
                double confianza = Math.Round(rnd.NextDouble() * (0.9 - 0.6) + 0.6, 2); // entre 0.6 y 0.9

                // --- Mostrar resultado en mensaje ---
                string mensaje = tieneCasco
                    ? $"🟢 Persona detectada CON CASCO\nConfianza: {confianza * 100}%"
                    : $"🔴 Persona detectada SIN CASCO\nConfianza: {confianza * 100}%";

                MessageBox.Show(mensaje, "Resultado de detección");

                // --- Actualizar UI del semáforo ---
                pbSemaforo.BackColor = tieneCasco ? Color.White : Color.Red;
                pbSemafor.BackColor = tieneCasco ? Color.Green : Color.White;
                lblSemaforo.Text = tieneCasco ? "Semáforo: VERDE" : "Semáforo: ROJO";

                // --- Mostrar el resultado visualmente sobre la imagen ---
                using (Graphics g = Graphics.FromImage(frameActual))
                {
                    Color color = tieneCasco ? Color.Lime : Color.Red;
                    Pen pen = new Pen(color, 5);
                    g.DrawRectangle(pen, 50, 50, frameActual.Width - 100, frameActual.Height - 100);
                    g.DrawString(
                        tieneCasco ? "CON CASCO" : "SIN CASCO",
                        new Font("Arial", 16, FontStyle.Bold),
                        new SolidBrush(color),
                        new PointF(20, 20)
                    );
                }

                // Actualiza el PictureBox con la imagen procesada
                pbCamara.Image = frameActual;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al simular la detección: {ex.Message}");
            }
        }


        //private async void btnDetect_Click(object sender, EventArgs e)
        //    {
        //        if (pbCamara.Image == null)
        //        {
        //            MessageBox.Show("No hay imagen de la cámara.");
        //            return;
        //        }

        //        try
        //        {
        //            using (var client = new HttpClient())
        //            {
        //                var url = "http://127.0.0.1:5000/detect";

        //                using (var ms = new MemoryStream())
        //                {
        //                    pbCamara.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
        //                    var content = new MultipartFormDataContent();
        //                    content.Add(new ByteArrayContent(ms.ToArray()), "image", "frame.jpg");

        //                    var response = await client.PostAsync(url, content);
        //                    var json = await response.Content.ReadAsStringAsync();

        //                    dynamic data = JsonConvert.DeserializeObject(json);

        //                    bool tieneCasco = data.helmet;
        //                    double confianza = data.confidence;

        //                    MessageBox.Show(
        //                        tieneCasco ? $"🟢 CON CASCO ({confianza * 100}%)" : $"🔴 SIN CASCO ({confianza * 100}%)"
        //                    );

        //                    pbSemaforo.BackColor = tieneCasco ? Color.Green : Color.Red;
        //                    lblSemaforo.Text = tieneCasco ? "Semáforo: VERDE" : "Semáforo: ROJO";
        //                }
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show("Error al comunicarse con el servidor: " + ex.Message);
        //        }
        //    }

        //private async void btnDetect_Click(object sender, EventArgs e)
        //{
        //    if (pbCamara.Image == null)
        //    {
        //        MessageBox.Show("No hay imagen de la cámara.");
        //        return;
        //    }

        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            // URL del servidor Flask donde se realizará la detección
        //            var url = "http://127.0.0.1:5000/detect";

        //            using (var ms = new MemoryStream())
        //            {
        //                // Guardamos la imagen capturada en formato JPEG
        //                pbCamara.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);

        //                var content = new MultipartFormDataContent();
        //                content.Add(new ByteArrayContent(ms.ToArray()), "image", "frame.jpg");

        //                // Enviamos la imagen al servidor Flask
        //                var response = await client.PostAsync(url, content);
        //                var json = await response.Content.ReadAsStringAsync();

        //                // Deserializamos la respuesta JSON del servidor
        //                dynamic data = JsonConvert.DeserializeObject(json);

        //                bool tieneCasco = data.helmet;         // Si el casco fue detectado
        //                double confianza = data.confidence;   // Nivel de confianza

        //                // Mostramos un mensaje con el resultado
        //                MessageBox.Show(
        //                    tieneCasco ? $"🟢 CON CASCO ({confianza * 100}%)" : $"🔴 SIN CASCO ({confianza * 100}%)"
        //                );

        //                // Cambiamos el color del semáforo según la detección
        //                pbSemaforo.BackColor = tieneCasco ? Color.Green : Color.Red;
        //                lblSemaforo.Text = tieneCasco ? "Semáforo: VERDE" : "Semáforo: ROJO";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error al comunicarse con el servidor: " + ex.Message);
        //    }
        //}


        // --- Liberar cámara al cerrar ---
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_fuenteVideo != null && _fuenteVideo.IsRunning)
                _fuenteVideo.SignalToStop();
        }
    }
}