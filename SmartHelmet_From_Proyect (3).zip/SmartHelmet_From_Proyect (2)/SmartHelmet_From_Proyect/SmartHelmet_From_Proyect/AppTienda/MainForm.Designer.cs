namespace AppSmartHelmet
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblSemaforo = new System.Windows.Forms.Label();
            this.dgvUltimas = new System.Windows.Forms.DataGridView();
            this.pbCamara = new System.Windows.Forms.PictureBox();
            this.btnIniciarCamara = new System.Windows.Forms.Button();
            this.btnDetenerCamara = new System.Windows.Forms.Button();
            this.btnDetect = new System.Windows.Forms.Button();
            this.pbSemaforo = new System.Windows.Forms.PictureBox();
            this.cmbCamaras = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pbSemafor = new System.Windows.Forms.PictureBox();
            this.proyectname = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUltimas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCamara)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSemaforo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSemafor)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSemaforo
            // 
            this.lblSemaforo.AutoSize = true;
            this.lblSemaforo.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSemaforo.Location = new System.Drawing.Point(585, 92);
            this.lblSemaforo.Name = "lblSemaforo";
            this.lblSemaforo.Size = new System.Drawing.Size(68, 13);
            this.lblSemaforo.TabIndex = 2;
            this.lblSemaforo.Text = "Semáforo: -";
            // 
            // dgvUltimas
            // 
            this.dgvUltimas.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvUltimas.BackgroundColor = System.Drawing.Color.Cyan;
            this.dgvUltimas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUltimas.Location = new System.Drawing.Point(134, 25);
            this.dgvUltimas.Name = "dgvUltimas";
            this.dgvUltimas.RowHeadersWidth = 62;
            this.dgvUltimas.Size = new System.Drawing.Size(900, 449);
            this.dgvUltimas.TabIndex = 3;
            // 
            // pbCamara
            // 
            this.pbCamara.BackColor = System.Drawing.Color.Black;
            this.pbCamara.Location = new System.Drawing.Point(281, 123);
            this.pbCamara.Margin = new System.Windows.Forms.Padding(2);
            this.pbCamara.Name = "pbCamara";
            this.pbCamara.Size = new System.Drawing.Size(195, 160);
            this.pbCamara.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCamara.TabIndex = 4;
            this.pbCamara.TabStop = false;
            // 
            // btnIniciarCamara
            // 
            this.btnIniciarCamara.Location = new System.Drawing.Point(775, 105);
            this.btnIniciarCamara.Margin = new System.Windows.Forms.Padding(2);
            this.btnIniciarCamara.Name = "btnIniciarCamara";
            this.btnIniciarCamara.Size = new System.Drawing.Size(108, 38);
            this.btnIniciarCamara.TabIndex = 5;
            this.btnIniciarCamara.Text = "Iniciar";
            this.btnIniciarCamara.UseVisualStyleBackColor = true;
            this.btnIniciarCamara.Click += new System.EventHandler(this.btnIniciarCamara_Click);
            // 
            // btnDetenerCamara
            // 
            this.btnDetenerCamara.Location = new System.Drawing.Point(775, 184);
            this.btnDetenerCamara.Margin = new System.Windows.Forms.Padding(2);
            this.btnDetenerCamara.Name = "btnDetenerCamara";
            this.btnDetenerCamara.Size = new System.Drawing.Size(108, 38);
            this.btnDetenerCamara.TabIndex = 6;
            this.btnDetenerCamara.Text = "Detener";
            this.btnDetenerCamara.UseVisualStyleBackColor = true;
            this.btnDetenerCamara.Click += new System.EventHandler(this.btnDetenerCamara_Click);
            // 
            // btnDetect
            // 
            this.btnDetect.Location = new System.Drawing.Point(775, 260);
            this.btnDetect.Margin = new System.Windows.Forms.Padding(2);
            this.btnDetect.Name = "btnDetect";
            this.btnDetect.Size = new System.Drawing.Size(108, 40);
            this.btnDetect.TabIndex = 7;
            this.btnDetect.Text = "Detectar";
            this.btnDetect.UseVisualStyleBackColor = true;
            this.btnDetect.Click += new System.EventHandler(this.btnDetect_Click);
            // 
            // pbSemaforo
            // 
            this.pbSemaforo.BackColor = System.Drawing.Color.White;
            this.pbSemaforo.Location = new System.Drawing.Point(595, 123);
            this.pbSemaforo.Margin = new System.Windows.Forms.Padding(2);
            this.pbSemaforo.Name = "pbSemaforo";
            this.pbSemaforo.Size = new System.Drawing.Size(43, 38);
            this.pbSemaforo.TabIndex = 9;
            this.pbSemaforo.TabStop = false;
            // 
            // cmbCamaras
            // 
            this.cmbCamaras.FormattingEnabled = true;
            this.cmbCamaras.Location = new System.Drawing.Point(394, 287);
            this.cmbCamaras.Margin = new System.Windows.Forms.Padding(2);
            this.cmbCamaras.Name = "cmbCamaras";
            this.cmbCamaras.Size = new System.Drawing.Size(82, 21);
            this.cmbCamaras.TabIndex = 10;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox1.Location = new System.Drawing.Point(564, 123);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(107, 160);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Location = new System.Drawing.Point(595, 184);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(43, 38);
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // pbSemafor
            // 
            this.pbSemafor.BackColor = System.Drawing.Color.White;
            this.pbSemafor.Location = new System.Drawing.Point(595, 245);
            this.pbSemafor.Margin = new System.Windows.Forms.Padding(2);
            this.pbSemafor.Name = "pbSemafor";
            this.pbSemafor.Size = new System.Drawing.Size(43, 38);
            this.pbSemafor.TabIndex = 13;
            this.pbSemafor.TabStop = false;
            // 
            // proyectname
            // 
            this.proyectname.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.proyectname.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.proyectname.Location = new System.Drawing.Point(283, 35);
            this.proyectname.Name = "proyectname";
            this.proyectname.Size = new System.Drawing.Size(600, 44);
            this.proyectname.TabIndex = 14;
            this.proyectname.Text = "AppSmartHelmet";
            this.proyectname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1214, 541);
            this.Controls.Add(this.proyectname);
            this.Controls.Add(this.pbSemafor);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pbSemaforo);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblSemaforo);
            this.Controls.Add(this.cmbCamaras);
            this.Controls.Add(this.btnDetect);
            this.Controls.Add(this.btnDetenerCamara);
            this.Controls.Add(this.btnIniciarCamara);
            this.Controls.Add(this.pbCamara);
            this.Controls.Add(this.dgvUltimas);
            this.Name = "MainForm";
            this.Text = "SmartHelmet - Simulación (WinForms)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUltimas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCamara)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSemaforo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSemafor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblSemaforo;
        private System.Windows.Forms.DataGridView dgvUltimas;
        private System.Windows.Forms.PictureBox pbCamara;
        private System.Windows.Forms.Button btnIniciarCamara;
        private System.Windows.Forms.Button btnDetenerCamara;
        private System.Windows.Forms.Button btnDetect;
        private System.Windows.Forms.PictureBox pbSemaforo;
        private System.Windows.Forms.ComboBox cmbCamaras;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pbSemafor;
        private System.Windows.Forms.TextBox proyectname;
    }
}
