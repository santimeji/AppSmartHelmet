using System;
using System.Windows.Forms;
using Dal;
using BILL;
using AppSmartHelmet;


namespace AppTienda
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var repo = new InMemoryRepository();
            var detService = new DeteccionService(repo);

            Application.Run(new MainForm(detService, repo));
        }
    }
}
