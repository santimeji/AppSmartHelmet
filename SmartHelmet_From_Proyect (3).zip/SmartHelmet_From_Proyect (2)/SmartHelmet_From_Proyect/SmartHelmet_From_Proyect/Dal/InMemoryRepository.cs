using System;
using System.Collections.Generic;
using System.Linq;
using Entity;

namespace Dal
{
    public class InMemoryRepository
    {
        private readonly List<Deteccion> _detecciones = new List<Deteccion>();
        private readonly List<Vehiculo> _vehiculos = new List<Vehiculo>();
        private readonly List<Semaforo> _semaforos = new List<Semaforo>();
        private int _detId = 1;
        public InMemoryRepository()
        {
            // seed a semaforo
            _semaforos.Add(new Semaforo { Id = 1, Ubicacion = "Interseccion Principal", EstadoActual = EstadoSemaforo.Rojo });
        }

        public Deteccion AddDeteccion(Deteccion d)
        {
            d.Id = _detId++;
            _detecciones.Add(d);
            return d;
        }

        public IEnumerable<Deteccion> GetUltimas(int count = 20) => _detecciones.OrderByDescending(x => x.Hora).Take(count);

        public Semaforo GetSemaforo() => _semaforos.First();

        public void UpdateSemaforo(Semaforo s)
        {
            var ex = _semaforos.First();
            ex.EstadoActual = s.EstadoActual;
            ex.UltimoCambio = s.UltimoCambio;
        }
    }
}
