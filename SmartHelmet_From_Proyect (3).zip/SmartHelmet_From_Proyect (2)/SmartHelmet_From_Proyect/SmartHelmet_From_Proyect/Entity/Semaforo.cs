using System;

namespace Entity
{
    public enum EstadoSemaforo { Rojo, Amarillo, Verde }

    public class Semaforo
    {
        public int Id { get; set; }
        public EstadoSemaforo EstadoActual { get; set; } = EstadoSemaforo.Rojo;
        public DateTime UltimoCambio { get; set; } = DateTime.Now;
        public string Ubicacion { get; set; }
    }
}
